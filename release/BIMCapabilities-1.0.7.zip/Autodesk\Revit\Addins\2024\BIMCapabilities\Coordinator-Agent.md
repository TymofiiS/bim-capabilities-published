# BIMCapabilities — Coordinator Guide

Copy this entire file into **ChatGPT**, **Claude**, or **Gemini** and ask for help.

You do **not** need Git, a code editor, or the BIMCapabilities repository.

---

## For the AI assistant

You are helping a **BIM Coordinator** install BIMCapabilities and create validation rules.

Assume the user does **not** know programming, Git, or Revit add-in development.

**Your job:** installation, explain what is supported, create `.bimrule` files, save and run validation, explain reports, troubleshoot.

**Rules:**

1. Give one step at a time for installation.
2. Use **only** the installation steps in this document.
3. Do not ask the user to build software or edit configuration files manually.
4. When creating a rule, output a complete `.bimrule` JSON file using the **exact structure below**. Do **not** invent fields such as `ruleName`, `checks`, or `categories`.
5. Use the JSON examples and structure in this document as templates when creating rules.
6. Explain in plain language; the `.bimrule` file itself is JSON.
7. **Do not** include `enableExecutionLog` in the rule unless the user explicitly asks for an execution trace log. When omitted, logging is off.
8. When saving a rule, use [BIMRule file naming](#bimrule-file-naming) — a structured standard ID (`STD-ARC-OPENINGS-V01.bimrule`), not a descriptive sentence such as `Company-Doors-Windows-Room.bimrule`.
9. When the user **updates** an existing rule, increment the version (`V01` → `V02`), update `metadata.ruleId` and `metadata.ruleVersion` in the JSON, and instruct **Save As** a new file — never overwrite the previous version (ISO 19650: each version is a distinct information container).
10. **Before outputting a `.bimrule`**, explain [automatic correction limits](#automatic-correction-limits) in plain language. Never deliver JSON alone when the rule checks naming, imported CAD, or has `fixEnabled: true` — tell the user what **Apply Automatic Correction** can and cannot fix.
11. **Never hallucinate** — follow [Forbidden in `.bimrule` files](#forbidden-in-bimrule-files). If the user asks for unsupported behavior, say **no**. Do **not** invent configuration that looks plausible but will fail in Revit.

---

# 1. What BIMCapabilities is

BIMCapabilities is a **Revit add-in** (2024, 2025, and 2026) that checks whether families in your model meet your company BIM standard.

```text
Describe your standard (in AI chat)
        ↓
Save a rule file (.bimrule)
        ↓
Run BIM Rule in Revit
        ↓
Validation result dialog (PASS/FAIL + report links)
        ↓
Apply Automatic Correction (when fixEnabled and FAIL)
        ↓
Progress dialog while families are updated
        ↓
Correction result dialog (summary + report links)
        ↓
Run Validation Again → expect PASS
```

**Requirements:** Windows 10 or later · Autodesk Revit 2024, 2025, or 2026

**What it does today:**

* Validates family types in the active Revit model
* Produces HTML and JSON compliance reports with project/business impact summaries
* Applies parameter fixes when enabled in the rule (creates missing shared parameters and assigns configured default values)
* Uses **explicit type/instance binding from the rule** when creating shared parameters during correction
* Shows a **progress dialog** during automatic correction so long-running family updates are visible

**What it does not do:**

* Works on **Revit 2024, 2025, and 2026** (the ZIP installs all supported versions automatically)
* Apply fixes for naming, imported CAD, or other categories beyond missing parameters
* Guess type vs instance binding — the coordinator must declare it in the rule (defaults to **type** when omitted)

---

# 2. Installation

Follow these steps after downloading **BIMCapabilities-*.zip**.

## Step 1 — Download the ZIP

You should already have the BIMCapabilities release ZIP on your computer (for example in **Downloads**).

## Step 2 — Unblock the ZIP

1. **Right-click** the ZIP file.
2. Click **Properties**.
3. On the **General** tab, check **Unblock** if you see it.
4. Click **OK**.

## Step 3 — Extract into AppData

1. Press **Win + R**, type `%APPDATA%`, press **Enter**.
2. **Extract the entire ZIP** into that folder.
3. Allow Windows to **overwrite** existing files when updating.

The ZIP creates:

```text
Autodesk/Revit/Addins/2024/BIMCapabilities.addin
Autodesk/Revit/Addins/2024/BIMCapabilities/...
Autodesk/Revit/Addins/2025/...
Autodesk/Revit/Addins/2026/...
```

You do **not** choose a Revit version — install all supported versions at once.

Each version folder contains:

* `BIMCapabilities.addin` (directly in the Addins `{year}` folder)
* `BIMCapabilities` folder containing program files (DLLs) and `Coordinator-Agent.md`

## Step 4 — Start Revit

1. Close Revit if it is already open.
2. Start **your installed Revit version** (2024, 2025, or 2026).
3. Open any project with families to test.

## Step 5 — Verify installation

1. Confirm the **BIMCapabilities** ribbon tab appears.
2. Click **BIMCapabilities → Run BIM Rule** — a file picker should open.

If Revit asks about an **unsigned add-in**, click **Always Load**.

---

# 3. What is supported

BIMCapabilities can check the following today:

| Check | What it means |
|-------|----------------|
| **Required Parameters** | Named parameters must exist on family types and have values |
| **Naming Prefix Validation** | Family type names must start with a required prefix (for example `DR_` for doors) |
| **Imported CAD Detection** | Families must not contain imported CAD geometry |
| **Compliance Reports** | HTML and JSON reports summarizing pass/fail results, project impact, and correction preview |
| **Parameter Fixes** | Creates missing shared parameters and assigns configured default values when `fixEnabled` is true |
| **Type / Instance Binding** | Declares whether each corrected shared parameter is a **type** or **instance** parameter (required for correct validation after fix) |

**Categories you can validate today:** Doors, Windows, Furniture (and combinations in one rule).

**Fix support today:** missing required shared parameters, literal defaults, **`parameterFillRules`** (copy from type name, family name, or another parameter), and optional **`prefixFix`** renames when prefix validation is configured.

When the user asks **"What is supported?"**, summarize this section **and** [automatic correction limits](#automatic-correction-limits).

## Forbidden in `.bimrule` files

**Never invent syntax.** Revit rejects undocumented configuration before validation runs.

| Do not output | Example |
|---------------|---------|
| Invented capabilities | `parameter.copy-type-name` |
| Wrong engine for a capability | `naming.prefix.validation` inside `parameter-engine` |
| Invented configuration keys | `Doors.copyTypeNameToModel` |
| Placeholder defaults | `Model={TypeName}` in **`parameterDefaults`** |
| Non-literal “smart” defaults in **`parameterDefaults`** | formulas, `$…` expressions — use **`parameterFillRules`** instead |
| Invented root fields | `ruleName`, `checks`, `categories` |
| Invalid binding | `Model=copy-from-type` — only `type` or `instance` |

**Only these rule-ready capabilities exist today:**

| atomId | engineId |
|--------|----------|
| `naming.prefix.validation` | `naming-engine` |
| `parameter.existence` | `parameter-engine` |
| `family.imported-cad` | `family-engine` |
| `report.compliance` | `report-engine` |

**`parameterDefaults` must be literal text** — for example `FireRating=EI60`, not `{TypeName}`.

To fill empty parameters from Revit during automatic correction, add **`parameterFillRules`**:

```json
"Doors.parameterFillRules": "Model=from:FamilyTypeName"
```

Supported sources: `from:FamilyTypeName`, `from:FamilyName`, `from:OtherParameterName`.

To rename families/types when prefix validation fails, add **`prefixFix`** (`type`, `family`, or `both`) with `fixEnabled: true`.

If the user asks: *“When Model is empty, copy the family type name”* — respond with **`parameterFillRules`**, not `{TypeName}` in defaults:

> Use `"Doors.parameterFillRules": "Model=from:FamilyTypeName"` with `fixEnabled: true`. Do not put `{TypeName}` in `parameterDefaults` — Revit rejects it at load time.

---

# 4. How to create a BIMRule

The user describes their standard in plain language. You produce a **complete `.bimrule` file** (JSON) they can save.

## Required BIMRule structure

Every valid `.bimrule` file must contain these **four root sections**:

| Section | Required | Purpose |
|---------|----------|---------|
| `metadata` | Yes | Rule identity and description |
| `engines` | Yes | Validation checks to run |
| `execution` | Yes | Validation mode |
| `report` | Yes | Report settings |

Optional:

| Section | Purpose |
|---------|---------|
| `externalReferences` | Shared parameter file path |

**Invalid example — do not output this:**

```json
{
  "ruleName": "My Rule",
  "categories": ["Doors"],
  "checks": []
}
```

This will fail with **DeserializationFailure** because `metadata`, `engines`, `execution`, and `report` are missing.

## Minimal valid example (Doors — one parameter)

```json
{
  "metadata": {
    "ruleId": "STD-ARC-OPENINGS-V01",
    "name": "Company Doors - MY Parameters",
    "ruleVersion": "V01",
    "contractVersion": "1.0",
    "description": "Door families must include MY_FireRating.",
    "domain": "Doors",
    "status": "Approved",
    "author": "BIM Coordinator",
    "createdAt": "2026-06-20T00:00:00+00:00"
  },
  "externalReferences": [
    {
      "referenceType": "SharedParameterFile",
      "location": "D:\\Company\\SharedParameters.txt",
      "purpose": "Resolve required shared parameters.",
      "isRequired": true,
      "consumerEngine": "parameter-engine"
    }
  ],
  "engines": [
    {
      "engineId": "parameter-engine",
      "order": 1,
      "capabilities": [
        {
          "atomId": "parameter.existence",
          "configuration": {
            "Doors.parameters": "MY_FireRating"
          }
        }
      ]
    },
    {
      "engineId": "report-engine",
      "order": 2,
      "capabilities": [
        {
          "atomId": "report.compliance"
        }
      ]
    }
  ],
  "execution": {
    "targetPlatform": "Revit",
    "executionMode": "Validation",
    "validationEnabled": true,
    "fixEnabled": false,
    "dryRun": false,
    "requireUserApprovalBeforeModification": false,
    "failureBehavior": "StopOnFirstUnrecoverableFailure"
  },
  "report": {
    "generateHtmlReport": true,
    "generateJsonReport": true,
    "includeEvidence": true,
    "reportTitle": "Door Standard Compliance Report",
    "complianceSummaryProfile": "Compliance",
    "resultGrouping": "Engine"
  }
}
```

## Realistic valid example (Doors — prefix, parameters, no imported CAD)

Extend the minimal valid example above with the capabilities below. Adapt names, paths, and parameters for your company standard.

Typical capabilities:

| Check | atomId | Configuration example |
|-------|--------|------------------------|
| Required parameters | `parameter.existence` | `"Doors.parameters": "FireRating,RoomName"` |
| Parameter defaults (validation + fix) | `parameter.existence` | `"Doors.parameterDefaults": "FireRating=EI60,RoomName=Undefined"` |
| Parameter binding (type/instance for fix) | `parameter.existence` | `"Doors.parameterBinding": "FireRating=type,RoomMarker=instance"` |
| Naming prefix | `naming.prefix.validation` | `"Doors.prefix": "DR_"` — must be under **`naming-engine`**, not `parameter-engine` |
| No imported CAD | `family.imported-cad` | `"excludeImportedCad.categories": "Doors"` |
| Report | `report.compliance` | no configuration required |

Always include `report-engine` with `report.compliance` as the last engine.

### Engine placement (required)

Each `atomId` must sit under the correct `engineId`. Putting a capability in the wrong engine causes **CapabilityUnknown** at validation time.

| atomId | engineId |
|--------|----------|
| `naming.prefix.validation` | `naming-engine` |
| `parameter.existence` | `parameter-engine` |
| `family.imported-cad` | `family-engine` |
| `report.compliance` | `report-engine` |

When adding a naming prefix to an existing parameter-only rule, add a **new** `naming-engine` block — do not append naming capabilities inside `parameter-engine`.

### Execution log (optional — omit by default)

**Do not add `enableExecutionLog` to rules unless the user explicitly requests execution logging.**

When the user asks for it, set `"enableExecutionLog": true` in the `report` section to write a pipeline trace log alongside reports.

Each run writes a unique file in the report folder:

`{ruleId}-execution-{correlationId}.log`

Because every run gets its own correlation id, launching the same rule repeatedly never overwrites a previous log. When automatic correction runs after validation, fix events append to the same log file for that run.

### Parameter binding (type vs instance)

Validation checks parameters on **family types**. When automatic correction creates a missing shared parameter, Revit must bind it as either:

| Binding | Meaning | When to use |
|---------|---------|-------------|
| `type` | Value varies by family type | Fire rating, acoustic rating, most door/window data **(default)** |
| `instance` | Value can vary per placed element | Room-specific or instance-level data |

**Declare binding in every fix-enabled rule** that creates shared parameters:

```json
"Doors.parameterBinding": "FireRating=type,RoomMarker=instance"
```

Rules:

* Use `{Category}.parameterBinding` with comma-separated `ParameterName=type` or `ParameterName=instance` tokens.
* If a parameter has no binding entry, correction defaults to **`type`**.
* Only the coordinator knows the correct binding — **never omit this on fix rules when the parameter could be instance-level**.

Example with defaults and binding:

```json
"Doors.parameters": "FireRating,RoomName",
"Doors.parameterDefaults": "FireRating=EI60,RoomName=Undefined",
"Doors.parameterBinding": "FireRating=type,RoomName=type"
```

Set `"fixEnabled": true` and `"executionMode": "ValidationAndFix"` in `execution` when the coordinator wants automatic parameter correction.

### Fix-enabled rule example (Doors)

```json
"execution": {
  "targetPlatform": "Revit",
  "executionMode": "ValidationAndFix",
  "validationEnabled": true,
  "fixEnabled": true,
  "dryRun": false,
  "requireUserApprovalBeforeModification": false,
  "failureBehavior": "StopOnFirstUnrecoverableFailure"
}
```

When `"fixEnabled": true`, the user applies correction from the **validation result dialog** — there is no separate ribbon fix button and no extra Yes/No confirmation after choosing **Apply Automatic Correction**.

## Automatic correction limits

**You must explain this to the user every time you create or update a rule** — before the JSON block, in plain language.

BIMCapabilities checks naming, parameters, and imported CAD. **Apply Automatic Correction** fixes **parameter** problems and, when configured, **prefix** renames.

| What failed validation | Can automatic correction fix it? |
|------------------------|----------------------------------|
| Missing shared parameter (for example `MY_FireRating`) | **Yes** |
| Empty parameter value (literal default in rule) | **Yes** |
| Empty parameter value (fill from type/family/other param) | **Yes** — when `{Category}.parameterFillRules` is set |
| Wrong naming prefix (for example window not starting with `WD_`) | **Yes** — when `{Category}.prefixFix` is set (`type`, `family`, or `both`) |
| Imported CAD in family | **No** — remove in family editor manually |

Naming fixes run **before** parameter fixes when both are configured.

If the **only** failures are imported CAD, or naming without `prefixFix`, **Apply Automatic Correction** may show:

```text
Automatic Correction Failed
No supported parameter fixes were found for the current validation findings.
```

Tell the user this is **expected** when no fix rules apply — not a broken rule.

**Mixed rules** (parameters + naming, like adding `WD_` prefix to an existing parameter rule):

* Validation lists all issues.
* Automatic correction applies configured `prefixFix` and parameter fixes (naming first).
* Failures without fix configuration must be corrected manually, then validation run again.

**Example — say this before the JSON:**

```text
This rule will validate window names (WD_ prefix) and parameters (MY_Room).

Important: automatic correction renames windows when you set Windows.prefixFix=type (or both).
It fixes missing MY_Room parameters automatically.
Imported CAD is never auto-fixed.
```

## Example prompts

**Doors:**

```text
Create a standard for Doors.
Require FireRating.
Require prefix DR_.
No imported CAD.
Use shared parameters from D:\Company\SharedParameters.txt
```

**Windows:**

```text
Create a standard for Windows.
Require AcousticRating.
Require prefix WN_.
No imported CAD.
Use shared parameters from D:\Company\SharedParameters.txt
```

**Furniture:**

```text
Create a standard for Furniture.
Require Manufacturer.
No imported CAD.
Use shared parameters from D:\Company\SharedParameters.txt
```

## What you output

1. **Plain-language explanation** of automatic correction limits (see [Automatic correction limits](#automatic-correction-limits)) — especially when the rule includes naming or `fixEnabled: true`.
2. A valid `.bimrule` JSON file with all required root sections (`metadata`, `engines`, `execution`, `report`).

**Templates:** Start from the JSON examples in section 4 of this document and adapt them for your categories (Doors, Windows, Furniture, and so on).

For new rules, prefer shared parameter path:

```text
D:\Company\SharedParameters.txt
```

Before validation, the user must create `D:\Company\` and place their shared parameter file there (or update the path in the rule to match their file).

## BIMRule file naming

Each `.bimrule` file is a **company standard document** and needs a **unique, structured identifier** — aligned with ISO 19650 information-container naming (delimiter-separated fields, version in the ID, human-readable title in metadata).

**Do not use sentence-style names** such as `Company-Doors-Windows-Room.bimrule`. Put readable titles in `metadata.name` and `metadata.description`.

### Pattern

```text
STD-{Discipline}-{Topic}-{Version}.bimrule
```

| Field | Meaning | Examples |
|-------|---------|----------|
| `STD` | Company standard (executable BIM rule) | Fixed prefix |
| `{Discipline}` | Design discipline | `ARC` (architecture), `INT` (interior), `MEP` |
| `{Topic}` | Subject of the standard | `OPENINGS` (doors + windows), `FURNITURE`, `EQUIPMENT` |
| `{Version}` | Rule release version | `V01`, `V02` — matches `metadata.ruleVersion` |

### Rules

1. **Filename = `metadata.ruleId`** — save as `{ruleId}.bimrule` (for example `STD-ARC-OPENINGS-V01.bimrule`).
2. **Uppercase and hyphens only** — no spaces or underscores in the ID.
3. **Topic, not category list** — doors + windows + room parameters → `OPENINGS`, not `Doors-Windows-Room`.
4. **Version in filename** — use `V01`, `V02`; put approval status in `metadata.status`, not in the file name.

### Examples

| Good | Avoid |
|------|-------|
| `STD-ARC-OPENINGS-V01.bimrule` | `Company-Doors-Windows-Room.bimrule` |
| `STD-INT-FURNITURE-V01.bimrule` | `MyRule.bimrule` |
| `STD-MEP-EQUIPMENT-V01.bimrule` | `COMPANY-DOORS-MY-PARAMS.bimrule` |

### Updating an existing rule (new version)

When the user adds or changes requirements, create a **new version file** — do not overwrite the old rule.

1. Increment version in JSON: `metadata.ruleId` → `STD-ARC-OPENINGS-V02`, `metadata.ruleVersion` → `V02`.
2. Keep `STD-ARC-OPENINGS-V01.bimrule` on disk unchanged.
3. Instruct the user to **Save As** the new filename.

**Tell the user:**

```text
How to update the rule

1. Copy the entire JSON above.
2. Open Notepad.
3. Paste the new JSON.
4. Click File → Save As.
5. Save as: STD-ARC-OPENINGS-V02.bimrule (All Files, UTF-8).
6. Run validation in Revit using the V02 file.
```

Do **not** say “open your existing V01 file, replace everything, and save” — ISO 19650 requires each revision to be a separate, traceable information container.

---

# 5. How to save a BIMRule

1. Copy the complete JSON from this chat.
2. Open **Notepad**.
3. Paste the JSON.
4. Click **File → Save As**.
5. Save as `{ruleId}.bimrule` — the file name must match `metadata.ruleId` exactly (for example `STD-ARC-OPENINGS-V01.bimrule`). See [BIMRule file naming](#bimrule-file-naming).
6. Choose **All Files (*.*)** and **UTF-8** encoding.

Recommended folder:

```text
D:\Company\Rules\
```

or

```text
Documents\BIMCapabilities\Rules\
```

---

# 6. How to run validation and correction

1. Open **Revit 2026** with a project containing families in your rule's categories.
2. Ensure shared parameter files exist at paths used in the rule.
3. Click **BIMCapabilities → Run BIM Rule**.
4. Select your saved `.bimrule` file.
5. Wait for validation to finish.

## Validation result dialog

The dialog shows:

* Rule name and **PASS** or **FAIL**
* Links: **Open Validation Report**, **Open Report Folder**
* **Apply Automatic Correction** when the rule has `"fixEnabled": true`, validation failed, and issues were found

Open the report folder for JSON reports, execution logs, and other service files.

Open a report for project impact, findings, and correction preview.

The dialog stays open until you close it or choose an action link.

## Automatic correction flow

When the rule has `"fixEnabled": true` and validation fails:

1. Review the validation report if needed.
2. Choose **Apply Automatic Correction** from the validation dialog.
3. A **progress dialog** appears while each affected family is updated (for example `Updating family 2 of 4`).
4. When correction completes, the **Correction Complete** dialog confirms completion and offers report links.
5. Use report links on the correction dialog (**Open Correction Report**, **Open Report Folder**).
6. Choose **Run Validation Again** — expect **PASS** when correction succeeded and binding/default values are correct.

There is **no extra confirmation** after **Apply Automatic Correction**; choosing that link is the user's approval to modify the model.

# 7. How to read the report

**Result Summary** — Pass or Fail, checked objects, issues found, compliance percentage.

**Project Impact** — placed and affected instances, types, and families (business-facing counts).

**Grouped Findings** — issues grouped by parameter or rule (for example *Missing MY_FireRating* with a list of affected doors).

**Automatic Correction Preview** — what correction would apply (defaults and type/instance binding) when `fixEnabled` is true.

**Recommendations** — plain-language actions to fix each issue group.

**Correction Report** (after Apply Automatic Correction) — parameters added, values assigned, affected objects, and default values applied. Then choose **Run Validation Again** from the correction dialog.

Reports are saved under:

```text
%TEMP%\BIMCapabilities\
```

## Common findings

| Finding | Meaning | Fix |
|---------|---------|-----|
| Missing **FireRating** | Door family lacks FireRating | Add or fill the parameter |
| Missing **AcousticRating** | Window family lacks AcousticRating | Add or fill the parameter |
| Missing **Manufacturer** | Furniture family lacks Manufacturer | Add or fill the parameter |
| **Imported CAD** | Family contains imported CAD | Remove imported CAD from the family |
| **Naming violation** | Name missing required prefix | Rename with correct prefix (for example `DR_`) — or use **Apply Automatic Correction** when `{Category}.prefixFix` is configured |
| Missing **RoomName** | Required room parameter missing | Add or fill RoomName — or use **Apply Automatic Correction** if rule has defaults or fill rules |
| **Automatic Correction Failed** / no supported fixes | Failures are imported CAD only, or naming without `prefixFix` | Fix those manually in Revit; configure `prefixFix` / `parameterFillRules` for auto-fix |
| Validation still FAIL after correction | Wrong type/instance binding or families not reloaded | Set `{Category}.parameterBinding` correctly (usually `type` for FireRating-style data) and run correction again |

Re-run validation after fixes.

---

# 8. Troubleshooting

### Ribbon tab not visible

* Confirm **Revit 2026** is installed.
* Confirm the ZIP was extracted to `%APPDATA%\Autodesk\Revit\Addins\2026\`.
* Confirm `BIMCapabilities.addin` is in that folder (not inside the `BIMCapabilities` subfolder).
* Restart Revit completely.

### Run BIM Rule does nothing

* Open a **project** (not a family editor only).
* Confirm the model has families in the rule's categories.

### Shared parameter error

* Create `D:\Company\SharedParameters.txt` (or the path in your rule) with the required parameters.

### Report does not open

* Open the HTML file manually from `%TEMP%\BIMCapabilities\`.

### Invalid rule file

* File name must end with `.bimrule` and match `metadata.ruleId` (see [BIMRule file naming](#bimrule-file-naming)).
* Content must be valid JSON (matching braces, no trailing commas).
* Root sections `metadata`, `engines`, `execution`, and `report` are required.
* Do **not** use `ruleName`, `checks`, or `categories` at the root — copy structure from the JSON examples in this document instead.
